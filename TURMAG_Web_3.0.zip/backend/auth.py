import os
from datetime import datetime,timedelta,timezone
from jose import jwt,JWTError
from passlib.context import CryptContext
SECRET=os.getenv("TURMAG_SECRET","CHANGE_THIS_SECRET_BEFORE_DEPLOYMENT")
pwd=CryptContext(schemes=["bcrypt"],deprecated="auto")
def hash_password(p): return pwd.hash(p)
def verify_password(p,h): return pwd.verify(p,h)
def create_token(u,r):
    return jwt.encode({"sub":u,"role":r,"exp":datetime.now(timezone.utc)+timedelta(hours=12)},SECRET,algorithm="HS256")
def decode_token(t):
    try:return jwt.decode(t,SECRET,algorithms=["HS256"])
    except JWTError:return None
