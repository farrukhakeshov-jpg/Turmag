from pathlib import Path\nfrom datetime import datetime,timezone
from fastapi import FastAPI,Depends,HTTPException,Header
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from sqlalchemy.orm import Session
from pydantic import BaseModel,Field
from .database import Base,engine,get_db
from .models import User,Product,Sale,Client,Supplier,Setting,Delivery,ChatMessage
from .auth import hash_password,verify_password,create_token,decode_token
ROOT=Path(__file__).resolve().parent.parent
Base.metadata.create_all(bind=engine)
app=FastAPI(title="TURMAG API",version="2.0")
app.mount("/static",StaticFiles(directory=ROOT/"frontend"),name="static")
ROLES={"owner","admin","cashier","courier","loader","merchandiser","accountant","client"}
def seed():
 db=next(get_db())
 if not db.query(User).filter_by(username="owner").first():db.add(User(username="owner",password_hash=hash_password("Turmag123!"),role="owner"))
 if db.query(Product).count()==0:db.add_all([Product(name="Товар пример",barcode="200000000001",quantity=25,retail_price=1500,wholesale_price=1300,purchase_price=1000),Product(name="Аксессуар пример",barcode="200000000002",quantity=12,retail_price=3500,wholesale_price=3200,purchase_price=2400)])
 db.commit();db.close()
seed()
class Login(BaseModel): username:str;password:str
class ProductIn(BaseModel): name:str;barcode:str="";quantity:int=0;retail_price:float=0;wholesale_price:float=0;purchase_price:float=0
class SaleIn(BaseModel): product_id:int;quantity:int=Field(gt=0)
class QRIn(BaseModel): value:str
class UserIn(BaseModel): username:str;password:str=Field(min_length=8);role:str
class ClientIn(BaseModel): name:str;phone:str="";debt:float=0;debt_limit:float=0
class PaymentIn(BaseModel): amount:float=Field(gt=0)
class SupplierIn(BaseModel): name:str;phone:str="";debt:float=0
def current_user(authorization:str|None=Header(default=None),db:Session=Depends(get_db)):
 if not authorization or not authorization.startswith("Bearer "):raise HTTPException(401,"Требуется вход")
 payload=decode_token(authorization[7:])
 if not payload:raise HTTPException(401,"Сессия истекла")
 u=db.query(User).filter_by(username=payload["sub"]).first()
 if not u:raise HTTPException(401,"Пользователь не найден")
 return u
def allow(user,roles):
 if user.role not in roles:raise HTTPException(403,"Недостаточно прав")
@app.get("/")
def home():return FileResponse(ROOT/"frontend/index.html")
@app.post("/api/login")
def login(d:Login,db:Session=Depends(get_db)):
 u=db.query(User).filter_by(username=d.username).first()
 if not u or not verify_password(d.password,u.password_hash):raise HTTPException(401,"Неверный логин или пароль")
 return {"access_token":create_token(u.username,u.role),"username":u.username,"role":u.role}
@app.get("/api/me")
def me(u:User=Depends(current_user)):return {"username":u.username,"role":u.role}
@app.get("/api/dashboard")
def dashboard(db:Session=Depends(get_db),u:User=Depends(current_user)):
 ps=db.query(Product).all();ss=db.query(Sale).all()
 return {"products":len(ps),"stock_units":sum(p.quantity for p in ps),"sales_count":len(ss),"revenue":round(sum(s.total for s in ss),2),"clients":db.query(Client).count(),"client_debt":sum(x.debt for x in db.query(Client).all()),"supplier_debt":sum(x.debt for x in db.query(Supplier).all())}
@app.get("/api/products")
def products(db:Session=Depends(get_db),u:User=Depends(current_user)):
 return [{"id":p.id,"name":p.name,"barcode":p.barcode,"quantity":p.quantity,"retail_price":p.retail_price,"wholesale_price":p.wholesale_price} for p in db.query(Product).all()]
@app.post("/api/products")
def add_product(d:ProductIn,db:Session=Depends(get_db),u:User=Depends(current_user)):
 allow(u,{"owner","admin"});p=Product(**d.model_dump());db.add(p);db.commit();db.refresh(p);return {"id":p.id}
@app.get("/api/sales")
def sales(db:Session=Depends(get_db),u:User=Depends(current_user)):
 return [{"id":s.id,"product_name":s.product_name,"quantity":s.quantity,"total":s.total,"cashier":s.cashier} for s in db.query(Sale).order_by(Sale.id.desc()).all()]
@app.post("/api/sales")
def add_sale(d:SaleIn,db:Session=Depends(get_db),u:User=Depends(current_user)):
 p=db.query(Product).filter_by(id=d.product_id).first()
 if not p:raise HTTPException(404,"Товар не найден")
 if p.quantity<d.quantity:raise HTTPException(400,"Недостаточно остатка")
 p.quantity-=d.quantity;s=Sale(product_name=p.name,quantity=d.quantity,total=p.retail_price*d.quantity,cashier=u.username);db.add(s);db.commit();return {"total":s.total}
@app.get("/api/clients")
def clients(db:Session=Depends(get_db),u:User=Depends(current_user)):
 return [{"id":x.id,"name":x.name,"phone":x.phone,"debt":x.debt,"debt_limit":x.debt_limit} for x in db.query(Client).all()]
@app.post("/api/clients")
def add_client(d:ClientIn,db:Session=Depends(get_db),u:User=Depends(current_user)):
 allow(u,{"owner","admin","accountant"});x=Client(**d.model_dump());db.add(x);db.commit();db.refresh(x);return {"id":x.id}
@app.post("/api/clients/{client_id}/payment")
def client_payment(client_id:int,d:PaymentIn,db:Session=Depends(get_db),u:User=Depends(current_user)):
 allow(u,{"owner","admin","accountant","cashier"});x=db.query(Client).filter_by(id=client_id).first()
 if not x:raise HTTPException(404,"Клиент не найден")
 if d.amount>x.debt:raise HTTPException(400,"Сумма больше долга")
 x.debt-=d.amount;db.commit();return {"debt":x.debt}
@app.get("/api/suppliers")
def suppliers(db:Session=Depends(get_db),u:User=Depends(current_user)):
 return [{"id":x.id,"name":x.name,"phone":x.phone,"debt":x.debt} for x in db.query(Supplier).all()]
@app.post("/api/suppliers")
def add_supplier(d:SupplierIn,db:Session=Depends(get_db),u:User=Depends(current_user)):
 allow(u,{"owner","admin","accountant"});x=Supplier(**d.model_dump());db.add(x);db.commit();db.refresh(x);return {"id":x.id}
@app.get("/api/users")
def users(db:Session=Depends(get_db),u:User=Depends(current_user)):
 allow(u,{"owner","admin"});return [{"id":x.id,"username":x.username,"role":x.role} for x in db.query(User).all()]
@app.post("/api/users")
def add_user(d:UserIn,db:Session=Depends(get_db),u:User=Depends(current_user)):
 allow(u,{"owner","admin"})
 if d.role not in ROLES:raise HTTPException(400,"Неизвестная роль")
 if db.query(User).filter_by(username=d.username).first():raise HTTPException(409,"Логин уже занят")
 x=User(username=d.username,password_hash=hash_password(d.password),role=d.role);db.add(x);db.commit();return {"message":"Сотрудник создан"}
@app.get("/api/qr")
def get_qr(db:Session=Depends(get_db),u:User=Depends(current_user)):
 x=db.query(Setting).filter_by(key="payment_qr").first();return {"value":x.value if x else ""}
@app.put("/api/qr")
def set_qr(d:QRIn,db:Session=Depends(get_db),u:User=Depends(current_user)):
 if u.role!="owner":raise HTTPException(403,"QR-кодом управляет только владелец")
 x=db.query(Setting).filter_by(key="payment_qr").first()
 if not x:x=Setting(key="payment_qr",value=d.value);db.add(x)
 else:x.value=d.value
 db.commit();return {"message":"QR обновлён"}
@app.get("/api/health")
def health():return {"status":"ok","service":"TURMAG","version":"2.0"}

class DeliveryIn(BaseModel):
    client_name:str
    phone:str=""
    address:str
    note:str=""
    total:float=0
class DeliveryUpdate(BaseModel):
    status:str
    courier:str=""
class MessageIn(BaseModel):
    message:str=Field(min_length=1,max_length=2000)
@app.get("/api/deliveries")
def deliveries(db:Session=Depends(get_db),u:User=Depends(current_user)):
    q=db.query(Delivery)
    if u.role=="courier":q=q.filter((Delivery.courier==u.username)|(Delivery.status=="new"))
    return [{"id":x.id,"client_name":x.client_name,"phone":x.phone,"address":x.address,"note":x.note,"status":x.status,"courier":x.courier,"total":x.total} for x in q.order_by(Delivery.id.desc()).all()]
@app.post("/api/deliveries")
def add_delivery(d:DeliveryIn,db:Session=Depends(get_db),u:User=Depends(current_user)):
    allow(u,{"owner","admin","cashier","accountant"})
    x=Delivery(**d.model_dump());db.add(x);db.commit();db.refresh(x);return {"id":x.id}
@app.patch("/api/deliveries/{delivery_id}")
def update_delivery(delivery_id:int,d:DeliveryUpdate,db:Session=Depends(get_db),u:User=Depends(current_user)):
    allow(u,{"owner","admin","courier"})
    if d.status not in {"new","assigned","on_way","delivered","cancelled"}:raise HTTPException(400,"Недопустимый статус")
    x=db.query(Delivery).filter_by(id=delivery_id).first()
    if not x:raise HTTPException(404,"Заказ не найден")
    if u.role=="courier" and x.courier not in {"",u.username}:raise HTTPException(403,"Заказ назначен другому курьеру")
    x.status=d.status
    if d.courier and u.role in {"owner","admin"}:x.courier=d.courier
    elif u.role=="courier":x.courier=u.username
    db.commit();return {"message":"Статус обновлён"}
@app.get("/api/chat")
def get_chat(db:Session=Depends(get_db),u:User=Depends(current_user)):
    return [{"id":x.id,"username":x.username,"role":x.role,"message":x.message,"created_at":x.created_at} for x in db.query(ChatMessage).order_by(ChatMessage.id.desc()).limit(100).all()][::-1]
@app.post("/api/chat")
def send_chat(d:MessageIn,db:Session=Depends(get_db),u:User=Depends(current_user)):
    x=ChatMessage(username=u.username,role=u.role,message=d.message,created_at=datetime.now(timezone.utc).isoformat())
    db.add(x);db.commit();db.refresh(x);return {"id":x.id}
