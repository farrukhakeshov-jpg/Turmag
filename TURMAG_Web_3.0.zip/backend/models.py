from sqlalchemy import String,Integer,Float
from sqlalchemy.orm import Mapped,mapped_column
from .database import Base
class User(Base):
    __tablename__="users"
    id:Mapped[int]=mapped_column(primary_key=True)
    username:Mapped[str]=mapped_column(String(80),unique=True,index=True)
    password_hash:Mapped[str]=mapped_column(String(255))
    role:Mapped[str]=mapped_column(String(30),default="cashier")
class Product(Base):
    __tablename__="products"
    id:Mapped[int]=mapped_column(primary_key=True)
    name:Mapped[str]=mapped_column(String(160))
    barcode:Mapped[str]=mapped_column(String(80),default="")
    quantity:Mapped[int]=mapped_column(Integer,default=0)
    retail_price:Mapped[float]=mapped_column(Float,default=0)
    wholesale_price:Mapped[float]=mapped_column(Float,default=0)
    purchase_price:Mapped[float]=mapped_column(Float,default=0)
class Sale(Base):
    __tablename__="sales"
    id:Mapped[int]=mapped_column(primary_key=True)
    product_name:Mapped[str]=mapped_column(String(160))
    quantity:Mapped[int]=mapped_column(Integer)
    total:Mapped[float]=mapped_column(Float)
    cashier:Mapped[str]=mapped_column(String(80))
class Client(Base):
    __tablename__="clients"
    id:Mapped[int]=mapped_column(primary_key=True)
    name:Mapped[str]=mapped_column(String(160))
    phone:Mapped[str]=mapped_column(String(50),default="")
    debt:Mapped[float]=mapped_column(Float,default=0)
    debt_limit:Mapped[float]=mapped_column(Float,default=0)
class Supplier(Base):
    __tablename__="suppliers"
    id:Mapped[int]=mapped_column(primary_key=True)
    name:Mapped[str]=mapped_column(String(160))
    phone:Mapped[str]=mapped_column(String(50),default="")
    debt:Mapped[float]=mapped_column(Float,default=0)
class Setting(Base):
    __tablename__="settings"
    id:Mapped[int]=mapped_column(primary_key=True)
    key:Mapped[str]=mapped_column(String(80),unique=True)
    value:Mapped[str]=mapped_column(String(500),default="")

class Delivery(Base):
    __tablename__="deliveries"
    id:Mapped[int]=mapped_column(primary_key=True)
    client_name:Mapped[str]=mapped_column(String(160))
    phone:Mapped[str]=mapped_column(String(50),default="")
    address:Mapped[str]=mapped_column(String(500))
    note:Mapped[str]=mapped_column(String(500),default="")
    status:Mapped[str]=mapped_column(String(30),default="new")
    courier:Mapped[str]=mapped_column(String(80),default="")
    total:Mapped[float]=mapped_column(Float,default=0)
class ChatMessage(Base):
    __tablename__="chat_messages"
    id:Mapped[int]=mapped_column(primary_key=True)
    username:Mapped[str]=mapped_column(String(80))
    role:Mapped[str]=mapped_column(String(30))
    message:Mapped[str]=mapped_column(String(2000))
    created_at:Mapped[str]=mapped_column(String(40))
